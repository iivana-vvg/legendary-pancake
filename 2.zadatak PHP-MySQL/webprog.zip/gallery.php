<?php 
	print '
	<h1>GALLERY</h1>

		<div id="gallery">
		<hr>
			<figure id="1">
				<img src="gallery/novalja1.jpg" alt="novalja1" title="novalja1" style="width:500px;height:400px;">
				<figcaption>Gradska plaža u Novalji<figcaption>
			</figure>
			<figure id="2">
				<img src="gallery/novalja2.jpg" alt="novalja2" title="novalja2" style="width:500px;height:400px;">
				<figcaption>Trg Loža u centru Novalje<figcaption>
			</figure>
			<figure id="3">
				<img src="gallery/novalja3.jpg" alt="novalja3" title="novalja3" style="width:500px;height:400px;">
				<figcaption>Pored kipa "Kate" kod turisticke zajednice grada Novalje<figcaption>
			</figure>
			<figure id="4">
				<img src="gallery/novalja4.jpg" alt="novalja4" title="novalja4" style="width:500px;height:400px;">
				<figcaption>Gradska plaža u Novalji<figcaption>
			</figure>
			
			<hr>
		</div>
			
<br/>
<br/>
<br/>
<br/>
<br/>
<br/><br/>';
?>