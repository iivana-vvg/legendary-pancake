<?php 
	print '
	<h1>Rentals</h1>
	<figure>
		<img src="img/avion.jpg" alt="Avion" title="Avion">
		<figcaption>Dobrodošli na naše stranice koje predstavljaju ponudu naseg smještaja i turističku ponudu grada Novalje. </figcaption>

		</figure>

		<p>  Na našim stranicama predstavit ćemo vam dio ponude koja ce vas, nadamo se, dovoljno zainteresirati da se odlučite odmoriti i provesti svoje dane odmora pod toplim suncem Novalje. </p>

		<p>  Najljepše sto vam nudi ovaj mali gradić su prostrane plaže i njihova osebujna ljepota te raznovrsni ugostiteljski, sportsko-rekreativni i zabavni sadržaji.</p>

		<p>  U nasem domačinstvu nudimo vam smještaj u dva objekta kapaciteta dvanaest apartmana različitih veličina te ostale objekte </p>

		<p>  Tijekom godina Rentals postali su sinonim za smjestaj festivalskih gostiju.</p>

		<p>  Ukoliko trazite smještaj za Hideout Festival, Hard Island Festival, Fresh Island Festival, Armada Croatia Festival, Croatia Rock Festival, Black Sheep Festival, Barrakud Festival, Stereoforest Festival, Sonus Festival te mnoga ostala dogadanja na Zrcu - smjestaj u nasim objektima vas je najbolji izbor! </p>
		
		<p>Source: <a href="https://zrce.com" target="_blank">Zrće events</a></p>
		
	<p>Social media:<br>

			<a href="https://www.instagram.com/mycroatia365/" target="_blank"><img src="https://cdn1.tnwcdn.com/wp-content/blogs.dir/1/files/2016/05/instagram-logo.png" alt="Instagram" title="Instagram" style="width:24px; margin-top:0.4em"></a>

			<a href="https://twitter.com/MyCroatia365" target="_blank"><img src="https://1000logos.net/wp-content/uploads/2017/06/Twitter-Logo.png" alt="Twitter" title="Twitter" style="width:24px; margin-top:0.4em"></a>

	</p>';
?>