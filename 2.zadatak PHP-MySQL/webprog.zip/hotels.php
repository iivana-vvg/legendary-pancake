<?php 
	print '
	<!DOCTYPE html>
<html>
	<head>
		
		<!-- CSS -->
		<link rel="stylesheet" href="style.css">
		<!-- End CSS -->
		<!-- meta elements -->
		<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta name="description" content="web stranica">
		<meta name="keywords" content="HTML,CSS">
		<meta name="author" content="Ivana Ivkovic">
		</head>
<body>
	
	<h1>Hotels</h1>
	<div class="hotels">
	
			<a href="hotels.php"><img src="hotels/hotel-Olea.jpg" alt="hotel-Olea" title="Hotel Olea" style="width:500px;height:400px;"></a>

			<h2>Hotel Olea****</h2>

			<p>Hotel Olea u ponudi ima smještaj s 4 zvjezdice, saunu i terasu za suncanje. U Novalji i okolici moguce je uzivati u raznim aktivnostima, poput vožnje bicikla.<a href="hotels.php">.</a></p>

			<p><time datetime="2020-05-25">Dostupan od 25 Svibnja 2020</time></p>

			<hr>

			<a href="hotels.php"><img src="hotels/hotel-joel.jpg" alt="hotel-joel" title="Hotel Joel" style="width:500px;height:400px;"></a>

			<h2>Hotel Joel****</h2>

			<p>Hotel raspolaže s 11 jednosobnih apartmana, 2 studio apartmana, 1 deluxe apartmanom i 2 depandansa, svaki od njih jedinstveno ureden, prilagoden i najzahtjevnijim standardima udobnosti. <a href="hotels.php">.</a></p>

			<p><time datetime="2020-06-26">Dostupan od 26 Lipnja 2020</time></p>

			<hr>

			<a href="hotels.php"><img src="hotels/Hotel-In-Excelsis.jpg" alt="Hotel-In-Excelsis" title="Hotel In Excelsis" style="width:500px;height:400px;"></a>

			<h2>Hotel In Excelsis****</h2>

			<p>Sve hotelske sobe ukljucuju prostor za sjedenje, TV ravnog ekrana s kabelskim programima te vlastitu kupaonicu sa sušilom za kosu i tušem. Sve jedinice u hotelu In Excelsis sadrze klima-uredaj i radni stol. <a href="hotels.php">.</a></p>

			<p><time datetime="2020-07-27">Dostupan od 27 Srpnja 2020</time></p>
		</div>	
			</body>
</html>';
	
	
?>